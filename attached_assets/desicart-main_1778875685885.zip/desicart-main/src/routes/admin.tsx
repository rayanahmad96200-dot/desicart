import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { products as initialProducts } from "@/lib/products";

type EditableProduct = {
  slug: string;
  name: string;
  price: string;
  img: string;
  tag: string;
};

export const Route = createFileRoute("/admin")({
  component: AdminPage,
});

function AdminPage() {
  const [code, setCode] = useState("");
  const [products, setProducts] = useState<EditableProduct[]>(
    initialProducts.map((product) => ({
      slug: product.slug,
      name: product.name,
      price: product.price,
      img: product.img,
      tag: product.tag ?? "",
    })),
  );

  const isAuthed = code === "DESICART-ADMIN57777";

  const exportText = useMemo(
    () =>
      products
        .map((product) => `${product.slug}|${product.name}|${product.price}|${product.img}|${product.tag}`)
        .join("\n"),
    [products],
  );

  const updateProduct = (slug: string, field: keyof EditableProduct, value: string) => {
    setProducts((current) => current.map((product) => (product.slug === slug ? { ...product, [field]: value } : product)));
  };

  const copyExport = async () => {
    await navigator.clipboard.writeText(exportText);
  };

  return (
    <div className="min-h-screen bg-background text-foreground px-4 py-10">
      <div className="mx-auto max-w-6xl space-y-6 rounded-3xl border border-border bg-card p-6 sm:p-8">
        <div>
          <p className="text-xs font-bold uppercase tracking-widest text-accent">Admin Panel</p>
          <h1 className="font-display text-3xl sm:text-4xl font-black">DesiCart Admin</h1>
          <p className="mt-2 text-sm text-muted-foreground">Enter the admin code to edit products, prices, and images.</p>
        </div>

        {!isAuthed ? (
          <div className="space-y-4 max-w-md">
            <input
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="Admin code"
              className="h-12 w-full rounded-full border border-input bg-background px-4 text-sm outline-none focus:border-accent"
            />
            <p className="text-sm text-muted-foreground">Hint: ask the site owner for the code.</p>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <p className="text-sm text-muted-foreground">Edit the fields below, then copy the export text and paste it into your product file.</p>
              <button onClick={copyExport} className="rounded-full bg-foreground px-5 py-2.5 text-sm font-bold text-background">
                Copy export
              </button>
            </div>

            <div className="grid gap-4">
              {products.map((product) => (
                <div key={product.slug} className="rounded-2xl border border-border p-4 sm:p-5 space-y-4">
                  <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                    <input value={product.name} onChange={(e) => updateProduct(product.slug, "name", e.target.value)} className="h-11 rounded-full border border-input bg-background px-4 text-sm outline-none focus:border-accent" placeholder="Product name" />
                    <input value={product.price} onChange={(e) => updateProduct(product.slug, "price", e.target.value)} className="h-11 rounded-full border border-input bg-background px-4 text-sm outline-none focus:border-accent" placeholder="Price" />
                    <input value={product.tag} onChange={(e) => updateProduct(product.slug, "tag", e.target.value)} className="h-11 rounded-full border border-input bg-background px-4 text-sm outline-none focus:border-accent" placeholder="Tag" />
                    <input value={product.img} onChange={(e) => updateProduct(product.slug, "img", e.target.value)} className="h-11 rounded-full border border-input bg-background px-4 text-sm outline-none focus:border-accent" placeholder="Image URL" />
                  </div>
                  <p className="text-xs text-muted-foreground break-all">{product.slug}</p>
                </div>
              ))}
            </div>

            <div className="rounded-2xl border border-border bg-background p-4">
              <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-2">Export text</p>
              <pre className="whitespace-pre-wrap break-all text-xs text-foreground">{exportText}</pre>
            </div>
          </div>
        )}

        <div className="flex justify-end">
          <Link to="/" className="rounded-full bg-foreground px-5 py-2.5 text-sm font-bold text-background">
            Back to store
          </Link>
        </div>
      </div>
    </div>
  );
}